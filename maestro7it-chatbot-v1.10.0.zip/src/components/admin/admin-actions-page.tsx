'use client'

import { useEffect, useState, useCallback } from 'react'
import { Card, CardContent } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from '@/components/ui/select'
import { History, Loader2, RefreshCw, Filter } from 'lucide-react'
import { api } from '@/lib/api-client'
import { toast } from 'sonner'

const ACTION_COLORS: Record<string, 'default' | 'secondary' | 'destructive' | 'outline'> = {
  'faq.create': 'default',
  'faq.update': 'secondary',
  'faq.delete': 'destructive',
  'category.create': 'default',
  'category.update': 'secondary',
  'category.delete': 'destructive',
  'settings.update': 'secondary',
  'bot.webhook.subscribe': 'default',
  'bot.webhook.unsubscribe': 'outline',
  'admin.account.create': 'default',
  'admin.account.update': 'secondary',
  'admin.account.delete': 'destructive',
  'admin.password.change': 'secondary',
  'kb.import': 'secondary',
}

const ENTITY_OPTIONS = ['FaqItem', 'Category', 'AdminAccount', 'BotSetting', 'BotCommand']

export function AdminActionsPage() {
  const [items, setItems] = useState<any[]>([])
  const [total, setTotal] = useState(0)
  const [actionStats, setActionStats] = useState<Array<{ action: string; count: number }>>([])
  const [loading, setLoading] = useState(true)
  const [actionFilter, setActionFilter] = useState('')
  const [entityFilter, setEntityFilter] = useState('all')

  const load = useCallback(async () => {
    setLoading(true)
    try {
      const params: Record<string, string> = {}
      if (actionFilter) params.action = actionFilter
      if (entityFilter !== 'all') params.entity = entityFilter
      const res = await api.listAdminActions(params)
      setItems(res.items || [])
      setTotal(res.total || 0)
      setActionStats(res.actionStats || [])
    } catch (e: any) {
      toast.error('Ошибка', { description: e?.message })
    } finally {
      setLoading(false)
    }
  }, [actionFilter, entityFilter])

  useEffect(() => { load() }, [load])

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between flex-wrap gap-3">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">Журнал действий</h1>
          <p className="text-sm text-muted-foreground">
            Аудит операций администраторов · Всего: {total}
          </p>
        </div>
        <Button variant="outline" size="sm" onClick={load} disabled={loading}>
          <RefreshCw className="h-4 w-4 mr-2" /> Обновить
        </Button>
      </div>

      {/* Action statistics */}
      {actionStats.length > 0 && (
        <Card>
          <CardContent className="pt-4">
            <div className="text-xs font-medium text-muted-foreground mb-2">Статистика по действиям:</div>
            <div className="flex flex-wrap gap-2">
              {actionStats.slice(0, 10).map((s) => (
                <Badge
                  key={s.action}
                  variant={ACTION_COLORS[s.action] || 'outline'}
                  className="text-[10px] cursor-pointer"
                  onClick={() => setActionFilter(s.action)}
                >
                  {s.action}: {s.count}
                </Badge>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Filters */}
      <Card>
        <CardContent className="pt-4">
          <div className="flex flex-wrap items-center gap-2">
            <Filter className="h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Фильтр по действию (например faq.create)..."
              value={actionFilter}
              onChange={(e) => setActionFilter(e.target.value)}
              className="flex-1 min-w-[200px] h-9"
            />
            <Select value={entityFilter} onValueChange={setEntityFilter}>
              <SelectTrigger className="w-[180px] h-9">
                <SelectValue placeholder="Все сущности" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Все сущности</SelectItem>
                {ENTITY_OPTIONS.map((e) => (
                  <SelectItem key={e} value={e}>{e}</SelectItem>
                ))}
              </SelectContent>
            </Select>
            {(actionFilter || entityFilter !== 'all') && (
              <Button
                variant="ghost"
                size="sm"
                onClick={() => { setActionFilter(''); setEntityFilter('all') }}
              >
                Сбросить
              </Button>
            )}
          </div>
        </CardContent>
      </Card>

      {/* List */}
      {loading ? (
        <div className="flex items-center justify-center h-48">
          <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
        </div>
      ) : items.length === 0 ? (
        <Card>
          <CardContent className="py-12 text-center text-muted-foreground">
            <History className="h-10 w-10 mx-auto mb-3 opacity-50" />
            <div className="text-sm">Записей не найдено</div>
          </CardContent>
        </Card>
      ) : (
        <div className="space-y-1">
          {items.map((a) => (
            <Card key={a.id}>
              <CardContent className="p-3">
                <div className="flex items-center gap-3">
                  <Badge
                    variant={ACTION_COLORS[a.action] || 'outline'}
                    className="text-[10px] font-mono shrink-0"
                  >
                    {a.action}
                  </Badge>
                  {a.entity && (
                    <span className="text-xs text-muted-foreground font-mono shrink-0">
                      {a.entity}
                    </span>
                  )}
                  {a.details && (
                    <span className="text-sm truncate flex-1 min-w-0">{a.details}</span>
                  )}
                  <span className="text-xs text-muted-foreground ml-auto shrink-0">
                    {new Date(a.createdAt).toLocaleString('ru-RU')}
                  </span>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  )
}
