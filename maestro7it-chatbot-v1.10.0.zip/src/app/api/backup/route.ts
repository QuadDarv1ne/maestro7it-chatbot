import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

/**
 * GET /api/backup?secret=XXX
 * Автоматический backup базы знаний.
 *
 * Защита: требует CRON_SECRET env variable, передаётся в ?secret=
 * Возвращает JSON с полной базой знаний + timestamp.
 *
 * Использование в cron:
 *   0 3 * * * curl -s "https://your-domain.ru/api/backup?secret=XXX" > /backups/kb-$(date +%Y%m%d).json
 */
export async function GET(req: NextRequest) {
  const { searchParams } = new URL(req.url)
  const secret = searchParams.get('secret')
  const expectedSecret = process.env.CRON_SECRET

  if (!expectedSecret) {
    return NextResponse.json(
      { ok: false, error: 'CRON_SECRET not configured' },
      { status: 503 },
    )
  }

  if (secret !== expectedSecret) {
    return NextResponse.json(
      { ok: false, error: 'unauthorized' },
      { status: 401 },
    )
  }

  try {
    const [categories, faqs, tags, accounts, commands, settings] = await Promise.all([
      db.category.findMany({ orderBy: { sortOrder: 'asc' } }),
      db.faqItem.findMany({
        orderBy: [{ isPinned: 'desc' }, { sortOrder: 'asc' }],
        include: { category: true, tags: { include: { tag: true } } },
      }),
      db.tag.findMany({ orderBy: { name: 'asc' } }),
      db.adminAccount.findMany({
        select: { id: true, email: true, name: true, role: true, isActive: true, createdAt: true, lastLoginAt: true },
      }),
      db.botCommand.findMany({ orderBy: { command: 'asc' } }),
      db.botSetting.findMany(),
    ])

    const backup = {
      version: '1.0',
      type: 'full-backup',
      timestamp: new Date().toISOString(),
      stats: {
        categories: categories.length,
        faqs: faqs.length,
        tags: tags.length,
        accounts: accounts.length,
        commands: commands.length,
        settings: settings.length,
      },
      data: {
        categories: categories.map((c) => ({
          name: c.name,
          slug: c.slug,
          emoji: c.emoji,
          sortOrder: c.sortOrder,
        })),
        tags: tags.map((t) => ({ name: t.name })),
        faqs: faqs.map((f) => ({
          question: f.question,
          answer: f.answer,
          keywords: f.keywords,
          isPinned: f.isPinned,
          isPublished: f.isPublished,
          sortOrder: f.sortOrder,
          category: f.category?.slug || null,
          tags: f.tags.map((t) => t.tag.name),
        })),
        accounts: accounts.map((a) => ({
          email: a.email,
          name: a.name,
          role: a.role,
          isActive: a.isActive,
          createdAt: a.createdAt,
          lastLoginAt: a.lastLoginAt,
        })),
        commands: commands.map((c) => ({
          command: c.command,
          description: c.description,
          response: c.response,
          isEnabled: c.isEnabled,
        })),
        settings: settings.map((s) => ({
          key: s.key,
          // Скрываем секретные значения
          value: ['MAX_BOT_TOKEN', 'WEBHOOK_SECRET'].includes(s.key) ? '***' : s.value,
        })),
      },
    }

    return NextResponse.json(backup, {
      headers: {
        'Content-Type': 'application/json; charset=utf-8',
        'Content-Disposition': `attachment; filename="maestro7it-backup-${new Date().toISOString().slice(0, 10)}.json"`,
      },
    })
  } catch (e: any) {
    return NextResponse.json(
      { ok: false, error: e?.message || 'Backup failed' },
      { status: 500 },
    )
  }
}
