import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { requireAdmin } from '@/lib/api-helpers'

/**
 * GET /api/admin-actions
 * Журнал действий администраторов с фильтрами.
 *
 * Query params:
 *  - action: фильтр по action (например "faq.create")
 *  - entity: фильтр по entity (FaqItem, Category, AdminAccount, etc.)
 *  - limit: количество записей (по умолчанию 200, макс 500)
 *  - offset: сдвиг для пагинации
 */
export async function GET(req: NextRequest) {
  const guard = await requireAdmin()
  if (!guard.ok) return guard.response

  const { searchParams } = new URL(req.url)
  const action = searchParams.get('action') || undefined
  const entity = searchParams.get('entity') || undefined
  const limit = Math.min(Number(searchParams.get('limit') || 200), 500)
  const offset = Math.max(Number(searchParams.get('offset') || 0), 0)

  const where: any = {}
  if (action) where.action = { contains: action }
  if (entity) where.entity = entity

  const [items, total, actionStats] = await Promise.all([
    db.adminActionLog.findMany({
      where,
      orderBy: { createdAt: 'desc' },
      take: limit,
      skip: offset,
    }),
    db.adminActionLog.count({ where }),
    // Группировка по action для статистики
    db.adminActionLog.groupBy({
      by: ['action'],
      _count: true,
      orderBy: { _count: { action: 'desc' } },
      take: 20,
    }).catch(() => []),
  ])

  return NextResponse.json({
    ok: true,
    items,
    total,
    actionStats: actionStats.map((s: any) => ({ action: s.action, count: s._count })),
  })
}
