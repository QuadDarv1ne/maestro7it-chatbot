/**
 * Тесты для bot-logic helpers.
 * Запуск: bun test tests/bot-logic.test.ts
 */

import { describe, it, expect } from 'bun:test'

// Импортируем parsePayload через тестовую обёртку
// (parsePayload не экспортируется, тестируем логику)

describe('bot-logic helpers', () => {
  // Тестируем логику парсинга payload напрямую
  function parsePayload(payload: string): { key: string; rest: string } {
    const idx = payload.indexOf(':')
    if (idx === -1) return { key: payload, rest: '' }
    return { key: payload.slice(0, idx), rest: payload.slice(idx + 1) }
  }

  describe('parsePayload', () => {
    it('парсит feedback payload', () => {
      const result = parsePayload('feedback:abc123:1')
      expect(result.key).toBe('feedback')
      expect(result.rest).toBe('abc123:1')
    })

    it('парсит category payload', () => {
      const result = parsePayload('category:devops')
      expect(result.key).toBe('category')
      expect(result.rest).toBe('devops')
    })

    it('парсит show payload', () => {
      const result = parsePayload('show:cmui3jwp0000ileg34abmfdpm')
      expect(result.key).toBe('show')
      expect(result.rest).toBe('cmui3jwp0000ileg34abmfdpm')
    })

    it('парсит more payload с пробелами', () => {
      const result = parsePayload('more:Расскажи про Docker')
      expect(result.key).toBe('more')
      expect(result.rest).toBe('Расскажи про Docker')
    })

    it('парсит payload без двоеточия', () => {
      const result = parsePayload('menu')
      expect(result.key).toBe('menu')
      expect(result.rest).toBe('')
    })

    it('парсит payload с несколькими двоеточиями', () => {
      const result = parsePayload('feedback:abc:1')
      expect(result.key).toBe('feedback')
      expect(result.rest).toBe('abc:1')
    })

    it('обрабатывает пустой payload', () => {
      const result = parsePayload('')
      expect(result.key).toBe('')
      expect(result.rest).toBe('')
    })

    it('обрабатывает payload с двоеточием в конце', () => {
      const result = parsePayload('key:')
      expect(result.key).toBe('key')
      expect(result.rest).toBe('')
    })

    it('обрабатывает payload начиная с двоеточия', () => {
      const result = parsePayload(':value')
      expect(result.key).toBe('')
      expect(result.rest).toBe('value')
    })
  })
})
